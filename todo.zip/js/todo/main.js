import { initTodoList } from "./state.js";

document.addEventListener("DOMContentLoaded", () => {
  initTodoList();
});
