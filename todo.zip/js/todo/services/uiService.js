
import { showToast } from "../utils/helpers.js";

export class UIService {
  initUI() {
    this.setupPageTransitions();
    this.animateCards();
  }

  setupPageTransitions() {
    const links = document.querySelectorAll("a");
    links.forEach((link) => {
      if (
        link.href &&
        !link.href.startsWith("javascript:") &&
        !link.href.startsWith("#") &&
        link.target !== "_blank"
      ) {
        link.addEventListener("click", (e) => {
          const loader = document.createElement("div");
          loader.className = "loader-container";
          loader.innerHTML = '<div class="loader"></div>';
          document.body.appendChild(loader);

          const removeLoader = () => {
            if (document.body.contains(loader)) {
              document.body.removeChild(loader);
            }
            window.removeEventListener("load", removeLoader);
          };

          window.addEventListener("load", removeLoader);
          setTimeout(removeLoader, 3000);
        });
      }
    });
  }

  animateCards() {
    document.querySelectorAll(".app-card").forEach((card) => {
      card.style.transition = "transform 0.3s ease";
      card.addEventListener("mouseenter", () => {
        card.style.transform = "translateY(-5px)";
      });
      card.addEventListener("mouseleave", () => {
        card.style.transform = "";
      });
    });
  }
}
