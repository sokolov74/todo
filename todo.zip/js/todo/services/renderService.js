import { elements } from "../utils/dom.js";
import { showToast } from "../utils/helpers.js";

export class RenderService {
  constructor(state, groupManager, todoList) {
    this.state = state;
    this.groupManager = groupManager;
    this.todoList = todoList;
    this.retryCount = 0;
  }

  renderAll() {
    try {
      if (!elements || !elements.groupsContainer || !elements.groupSelector) {
        if (this.retryCount < 3) {
          this.retryCount++;
          setTimeout(() => this.renderAll(), 100);
          return;
        }
        throw new Error("Critical DOM elements not found");
      }

      this.groupManager.renderGroupSelector();
      this.todoList.renderTodos();
      this.todoList.updateCounters();
      this.updateUIState();
    } catch (error) {
      console.error("Render error:", error);
      this.handleRenderError();
    }
  }

  updateUIState() {
    const hasGroups = this.state.groups.length > 0;
    const groupSelected = !!this.state.currentGroup;

    elements.todoInput.disabled = !hasGroups || !groupSelected;
    elements.todoInput.placeholder = !hasGroups
      ? "Сначала создайте группу"
      : !groupSelected
      ? "Сначала выберите группу"
      : "Добавьте новую задачу...";

    elements.addBtn.disabled = !groupSelected;
    elements.noGroupsMessage.style.display = hasGroups ? "none" : "block";
  }

  handleRenderError() {
    try {
      localStorage.clear();
      this.state.todos = [];
      this.state.groups = [];
      this.state.currentGroup = "";
      location.reload();
    } catch (e) {
      console.error("Recovery failed:", e);
      showToast("Произошла критическая ошибка", "error");
    }
  }
}
